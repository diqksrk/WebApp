<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>Team Fried Chicken</title>
		
		<meta name="author" content="Team Fried Chicken" />
		<meta name="description" content="WebProgramming Team Project" />
		<!-- <meta name="keywords" content="" /> -->
		
		<link rel="stylesheet" type="text/css" href="main.css" />
		<!-- <link href="./img/favicon.png" type="image/png" rel="shortcut icon" /> -->
	</head>

	<body>
	<div id="page">
		<header>
			<h1>
				TEAM FRIED CHICKEN
			</h1>
		</header>
		
		<nav>
			<ul>
				<li><a href="">지역</a></li>
				<li><a href="">계절</a></li>
				<li><a href="">진행중</a></li>
			</ul>
		</nav>

		<nav>
			<form id="banner" action="">
				<input id="leftarrow" type="button" /><h1>지역별</h1><input id="rightarrow" type="button" />
			</form>
		</nav>
		
		<article>
			<section id="firstSection">
				<h1>빙어축제</h1>
				<h2>날짜: 2017.11.14 ~ 2017.12.14</h2>
				<p><img src="빙어축제.jpg" alt="빙어축제"></p>
			</section>

			<section id="secondSection">
				<h1 alt="축제이름">축제이름2</h1>
				<h2 alt="날짜">날짜2</h2>
				<p><img src="" alt=""></p>
			</section>

			<section id="thirdSection">
				<h1 alt="축제이름">축제이름3</h1>
				<h2 alt="날짜">날짜3</h2>
				<p><img src="" alt=""></p>
			</section>

			<section id="firstSection">
				<h1>빙어축제</h1>
				<h2>날짜: 2017.11.14 ~ 2017.12.14</h2>
				<p><img src="빙어축제.jpg" alt="빙어축제"></p>
			</section>

			<section id="secondSection">
				<h1 alt="축제이름">축제이름2</h1>
				<h2 alt="날짜">날짜2</h2>
				<p><img src="" alt=""></p>
			</section>

			<section id="thirdSection">
				<h1 alt="축제이름">축제이름3</h1>
				<h2 alt="날짜">날짜3</h2>
				<p><img src="" alt=""></p>
			</section>

			<section id="firstSection">
				<h1>빙어축제</h1>
				<h2>날짜: 2017.11.14 ~ 2017.12.14</h2>
				<p><img src="빙어축제.jpg" alt="빙어축제"></p>
			</section>

			<section id="secondSection">
				<h1 alt="축제이름">축제이름2</h1>
				<h2 alt="날짜">날짜2</h2>
				<p><img src="" alt=""></p>
			</section>

			<section id="thirdSection">
				<h1 alt="축제이름">축제이름3</h1>
				<h2 alt="날짜">날짜3</h2>
				<p><img src="" alt=""></p>
			</section>

		</article>
	</div>
			
			
	
	</body>
</html>